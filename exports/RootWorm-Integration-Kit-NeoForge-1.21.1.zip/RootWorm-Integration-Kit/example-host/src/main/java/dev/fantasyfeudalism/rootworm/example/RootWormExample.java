package dev.fantasyfeudalism.rootworm.example;

import dev.fantasyfeudalism.rootworm.RootWormModule;
import dev.fantasyfeudalism.rootworm.client.RootWormClient;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;

/** Example host only: do not copy this @Mod class into an already existing mod. */
@Mod(RootWormModule.MOD_ID)
public final class RootWormExample {
    public RootWormExample(IEventBus bus, ModContainer container, Dist dist) {
        RootWormModule.register(bus, container);
        if (dist == Dist.CLIENT) RootWormClient.register(bus);
    }
}
