#!/usr/bin/env python3
"""Run in the extracted kit before merging src into the destination mod."""
from pathlib import Path
import argparse, hashlib, json, re, shutil
root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--mod-id', required=True)
parser.add_argument('--package', required=True)
args = parser.parse_args()
if not re.fullmatch(r'[a-z][a-z0-9_]{1,63}', args.mod_id): parser.error('Use a valid NeoForge mod ID.')
if not re.fullmatch(r'[a-zA-Z_]\w*(?:\.[a-zA-Z_]\w*)+', args.package): parser.error('Use a Java package, e.g. com.example.mymod.rootworm.')
manifest = json.loads((root / 'SOURCE_MANIFEST.json').read_text())
old_id, old_package = manifest['namespace'], manifest['java_package']
for path in sorted(root.rglob('*')):
    if not path.is_file() or any(part in {'.gradle', 'build', 'run', 'runs', '.git'} for part in path.relative_to(root).parts): continue
    if path.suffix not in {'.java', '.json', '.toml', '.gradle', '.md'} or path.name == 'SOURCE_MANIFEST.json': continue
    text = path.read_text()
    text = text.replace(old_package, args.package)
    text = text.replace('"' + old_id + '"', '"' + args.mod_id + '"').replace("'" + old_id + "'", "'" + args.mod_id + "'")
    for a, b in [(old_id + ':', args.mod_id + ':'), ('entity.' + old_id + '.', 'entity.' + args.mod_id + '.'),
                 ('item.' + old_id + '.', 'item.' + args.mod_id + '.'), ('dependencies.' + old_id, 'dependencies.' + args.mod_id),
                 ('assets/' + old_id, 'assets/' + args.mod_id), ('data/' + old_id, 'data/' + args.mod_id),
                 ('`' + old_id + '`', '`' + args.mod_id + '`'), (old_package.replace('.', '/'), args.package.replace('.', '/'))]:
        text = text.replace(a, b)
    path.write_text(text)
for source in [root / 'src/main/java', root / 'example-host/src/main/java', root / 'example-host/src/gametest/java']:
    old, new = source / old_package.replace('.', '/'), source / args.package.replace('.', '/')
    if old != new and old.exists():
        temp = source / '.rootworm-retarget-temp'
        old.rename(temp)
        new.parent.mkdir(parents=True, exist_ok=True)
        temp.rename(new)
for source in [root / 'src/main/resources/assets', root / 'src/main/resources/data', root / 'example-host/src/gametest/resources/data']:
    old, new = source / old_id, source / args.mod_id
    if old != new and old.exists(): old.rename(new)
manifest['namespace'], manifest['java_package'] = args.mod_id, args.package
manifest['files'] = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*'))
    if p.is_file() and p.name != 'SOURCE_MANIFEST.json' and not any(part in {'.gradle','build','run','runs','.git'} for part in p.relative_to(root).parts)}
(root / 'SOURCE_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Retargeted kit to', args.mod_id, args.package)
