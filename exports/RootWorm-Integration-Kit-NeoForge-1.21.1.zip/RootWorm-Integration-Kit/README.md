# Root Worm integration kit

Source export from Fantasy Feudalism - Biomes 0.6.1 for **Minecraft 1.21.1, NeoForge 21.1.262+, Java 21**.

## Included

- The original 128x64 Root Worm PNG with a customized Java model: green back meshes removed, identical mirrored eyes with true-black pupils, the original blink, renderer and shared nine-segment geometry.
- Procedural Java animations: slithering, idle movement/blinking, cosmetic idle nibbling, and an attack-only opening mouth with a faster 9-tick animation and 3-tick windup, synchronized from the server (the 20-tick attack cooldown is unchanged).
- A raised searching animation inspired by an inchworm: the front and middle arch upward while the rear three segments stay planted, and the head slowly scans side to side with its mouth closed. It eases up/down over 10 ticks, pauses to listen for 52 ticks after hearing a sound, and searches again upon reaching the remembered location. Combat, heat, water and movement interrupt the pose; low ceilings prevent raising. The model and multipart hitboxes share the search curve and synchronized world-time transitions, including for clients that start tracking mid-animation.
- Neutral, hearing-guided AI: investigate eating, footsteps/running, jumping/landing, damage, block breaking/placing, armor equipping and held-item changes. Running/loud actions reach 16 blocks by default; normal footsteps reach half that and sneaking footsteps are ignored. Remembered sound locations expire after 80 ticks. Hearing alone does not cause aggression. Retaliatory bites use the head reach and a short lunge so slowly retreating targets can be bitten. Solid blocks still stop bites. Configurable fire/lava weakness, vanilla fire/lava avoidance and panic while burning are retained.
- Nine multipart damage boxes, correct part IDs and lifecycle, normal melee handling, arrow/potion/fire forwarding, scaling, teleports and name tags.
- Entity/attribute/spawn-egg registration, spawn placement registration, independent behavior config, client registration, translations and the original empty loot table.
- A small example host and isolated GameTests, plus a retargeting tool and per-file SHA-256 manifest.

The model and animations are Java source (`client/RootWormModel.java`), not GeckoLib/Blockbench animation JSON. No GeckoLib or Lithostitched dependency is required. The green atlas tile is unused after removing the back meshes; pupils are rendered true black by the model, so both eyes match without relying on different texture faces. There are no custom sound assets in the original implementation.

## No habitat dependencies

No Rootlands biome, worldgen, surface rules, custom blocks, root-food tags, heat-source tags or block lists are included. Root-seeking AI has been removed; idle nibbling is cosmetic and never reads or destroys root blocks. Heat avoidance recognizes Minecraft's built-in fire/lava only. Spawn placement uses normal Minecraft ground-spawn rules on ordinary valid ground; there is no custom biome, rooted-dirt, grass-block or root-density check. This kit does not automatically add the creature to any biome.

## Merge into an existing mod

1. Extract this ZIP, then retarget the **kit** to your destination mod ID and Java package:

   ```sh
   python3 tools/retarget.py --mod-id yourmod --package com.example.yourmod.rootworm
   ```

   This updates Java imports, resource namespaces/paths, translations, the example host and checksums. Run it before copying into your actual mod. The unmodified example namespace is `rootworm`.

2. Merge **only `src/main/java/` and `src/main/resources/`** into your existing mod. Keep its current build files and mod entry point. Do not copy `example-host/` or add a second `@Mod` class. Merge language/loot files if those paths already exist.

3. In your existing mod constructor, call the module once:

   ```java
   RootWormModule.register(modBus, container);
   if (dist == net.neoforged.api.distmarker.Dist.CLIENT) {
       RootWormClient.register(modBus);
   }
   ```

   Use the `IEventBus`, `ModContainer` and `Dist` supplied by NeoForge, as demonstrated by `example-host/.../RootWormExample.java`. `RootWormClient` is client-only; keep its registration inside the client branch. The module uses a separate `<modid>-root-worm-common.toml` config, so your existing common config can stay in place.

4. Append this to your existing `META-INF/neoforge.mods.toml` (keep all existing mixin entries):

   ```toml
   [[mixins]]
   config="rootworm-module.mixins.json"
   ```

   This mixin retains normal arrow damage, fire and tipped/spectral effects on multipart hits. The module's common registration also installs the melee forwarding listener; do not omit it.

5. Add Root Worm spawn entries wherever you want in the **new mod's own biome definitions or spawn configuration**. For example, under a biome's `spawners.creature` list, add an entry of this form using your destination namespace:

   ```json
   {"type": "yourmod:root_worm", "weight": 30, "minCount": 2, "maxCount": 4}
   ```

   There are deliberately no biome files or biome modifiers in this kit. Your mod chooses every natural spawn location. Normal Minecraft collision, ground placement, mob caps and spawn timing still apply.

6. Test with `/summon yourmod:root_worm ~ ~ ~` and `/give @s yourmod:root_worm_spawn_egg`. The egg appears in vanilla Spawn Eggs. Add `RootWormModule.ROOT_WORM_EGG` to your own creative tab if desired. Use F3+B to inspect the multipart hitboxes.

## Paths and optional changes

- Texture: `src/main/resources/assets/rootworm/textures/entity/root_worm.png` (128x64 RGBA).
- Model/animations: `src/main/java/dev/fantasyfeudalism/rootworm/client/RootWormModel.java`.
- Renderer: `client/RootWormRenderer.java`; shared model/hitbox sizes: `entity/RootWormShape.java`; raised search curve: `entity/RootWormSearchPose.java`.
- Behavior/attacks: `entity/RootWorm.java`, `entity/RootWormAttackGoal.java`; hearing/investigation: `entity/RootWormHearing.java`, `entity/InvestigateSoundGoal.java`; heat avoidance: `entity/AvoidHeatGoal.java`.
- Multipart damage: `entity/RootWormPart.java`; arrow forwarding: `mixin/RootWormArrowMixin.java`.
- Registration/config: `RootWormModule.java`, `RootWormConfig.java`; client registration: `client/RootWormClient.java`.

The original thorn immunity was implemented in the original Thorn block's contact handler. No thorn block is exported. If the destination mod has thorns, skip contact effects for `entity instanceof RootWorm` in that block's own handler. The worm itself has no custom block dependency.

The empty loot table preserves the original no-item-drop behavior; replace it in your mod if you want drops. Do not register RootWormPart as a separate entity type, spawn it separately, or remove the parent's ID reservation/part lifecycle code.

## Build the optional isolated example

From the extracted kit, run `./gradlew build` and `./gradlew runGameTestServer` (Windows: `gradlew.bat`). `./gradlew runClient` launches the example client. The example uses only NeoForge/Minecraft, without the original biome mod or Lithostitched. GameTests and the test arena are excluded from its built JAR. Client rendering still needs an in-game visual review.

`example-host/` is a validation/demo host, not required when merging the core `src/` tree into your existing mod. Source provenance and exact file hashes are recorded in `SOURCE_MANIFEST.json`; the original source licensing is unchanged. The build scaffold's template license is retained under `example-host/TEMPLATE_LICENSE.txt`.
